
import React, { useState } from 'react'
import { ShoppingCart, Plus, Minus, Trash2, ArrowRight, Tag, Truck, Shield, CreditCard } from 'lucide-react'
import toast from 'react-hot-toast'
import { useCart } from '../context/CartContext'

const Cart: React.FC = () => {
  const { items, updateQuantity, removeFromCart, getTotalPrice, clearCart } = useCart()
  const [couponCode, setCouponCode] = useState('')
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null)

  const subtotal = getTotalPrice()
  const shipping = subtotal > 100 ? 0 : 15.90
  const discount = appliedCoupon ? (subtotal * appliedCoupon.discount) / 100 : 0
  const total = subtotal + shipping - discount

  const handleQuantityChange = (id: string, newQuantity: number) => {
    if (newQuantity < 1) return
    updateQuantity(id, newQuantity)
  }

  const handleRemoveItem = (id: string, title: string) => {
    removeFromCart(id)
    toast.success(`${title} removido do carrinho`)
  }

  const handleApplyCoupon = () => {
    const validCoupons = {
      'PRIMEIRA10': { discount: 10, description: '10% de desconto na primeira compra' },
      'FRETE20': { discount: 20, description: '20% de desconto' },
      'HQ15': { discount: 15, description: '15% de desconto em HQs' }
    }

    const coupon = validCoupons[couponCode.toUpperCase() as keyof typeof validCoupons]
    
    if (coupon) {
      setAppliedCoupon({ code: couponCode.toUpperCase(), discount: coupon.discount })
      toast.success(`Cupom aplicado! ${coupon.description}`)
      setCouponCode('')
    } else {
      toast.error('Cupom inválido')
    }
  }

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error('Seu carrinho está vazio')
      return
    }

    // Simulate checkout process
    toast.success('Redirecionando para o pagamento...')
    setTimeout(() => {
      clearCart()
      toast.success('Pedido realizado com sucesso!')
    }, 2000)
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="bg-white rounded-2xl shadow-xl p-12 max-w-md mx-auto">
          <div className="text-gray-400 mb-6">
            <ShoppingCart className="h-24 w-24 mx-auto" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Seu carrinho está vazio
          </h2>
          <p className="text-gray-600 mb-8">
            Adicione algumas HQs incríveis para começar suas aventuras!
          </p>
          <div className="space-y-4">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold text-gray-900 mb-2">💡 Sugestões para você:</h3>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• Explore nossa coleção completa de Tintim</li>
                <li>• Descubra as aventuras hilariantes de Asterix</li>
                <li>• Confira os clássicos dos super-heróis</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-8 text-white">
        <div className="flex items-center space-x-4">
          <div className="bg-white bg-opacity-20 p-3 rounded-xl">
            <ShoppingCart className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-4xl font-bold mb-2">Seu Carrinho</h1>
            <p className="text-xl opacity-90">
              {items.length} {items.length === 1 ? 'item' : 'itens'} selecionados
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Itens do Carrinho</h2>
            
            <div className="space-y-6">
              {items.map((item) => (
                <div key={item.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                  {/* Image */}
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-20 h-20 object-cover rounded-lg"
                  />

                  {/* Details */}
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-gray-900 mb-1">
                      {item.title}
                    </h3>
                    <p className="text-green-600 font-bold text-xl">
                      R$ {item.price.toFixed(2)}
                    </p>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                      className="w-8 h-8 flex items-center justify-center bg-gray-200 text-gray-700 rounded-full hover:bg-gray-300 transition-colors"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    
                    <span className="w-12 text-center font-bold text-lg">
                      {item.quantity}
                    </span>
                    
                    <button
                      onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                      className="w-8 h-8 flex items-center justify-center bg-gray-200 text-gray-700 rounded-full hover:bg-gray-300 transition-colors"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>

                  {/* Subtotal */}
                  <div className="text-right min-w-24">
                    <div className="font-bold text-lg text-gray-900">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </div>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => handleRemoveItem(item.id, item.title)}
                    className="w-8 h-8 flex items-center justify-center text-red-500 hover:bg-red-50 rounded-full transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Coupon Section */}
            <div className="mt-8 pt-6 border-t border-gray-200">
              <h3 className="font-bold text-lg text-gray-900 mb-4">Cupom de Desconto</h3>
              <div className="flex space-x-3">
                <div className="flex-1 relative">
                  <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    placeholder="Digite seu cupom"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
                <button
                  onClick={handleApplyCoupon}
                  className="bg-gray-900 text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
                >
                  Aplicar
                </button>
              </div>
              
              {appliedCoupon && (
                <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-green-800 font-medium">
                      Cupom {appliedCoupon.code} aplicado
                    </span>
                    <button
                      onClick={() => setAppliedCoupon(null)}
                      className="text-green-600 hover:text-green-800 text-sm"
                    >
                      Remover
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-4 text-sm text-gray-600">
                <p className="font-medium mb-2">Cupons disponíveis:</p>
                <ul className="space-y-1">
                  <li>• <span className="font-mono bg-gray-100 px-2 py-1 rounded">PRIMEIRA10</span> - 10% de desconto na primeira compra</li>
                  <li>• <span className="font-mono bg-gray-100 px-2 py-1 rounded">HQ15</span> - 15% de desconto em HQs</li>
                  <li>• <span className="font-mono bg-gray-100 px-2 py-1 rounded">FRETE20</span> - 20% de desconto</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="space-y-6">
          {/* Summary Card */}
          <div className="bg-white rounded-xl shadow-lg p-6 sticky top-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Resumo do Pedido</h2>
            
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal ({items.length} {items.length === 1 ? 'item' : 'itens'})</span>
                <span className="font-medium">R$ {subtotal.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Frete</span>
                <span className="font-medium">
                  {shipping === 0 ? (
                    <span className="text-green-600">Grátis</span>
                  ) : (
                    `R$ ${shipping.toFixed(2)}`
                  )}
                </span>
              </div>
              
              {appliedCoupon && (
                <div className="flex justify-between text-green-600">
                  <span>Desconto ({appliedCoupon.discount}%)</span>
                  <span>-R$ {discount.toFixed(2)}</span>
                </div>
              )}
              
              <div className="border-t border-gray-200 pt-4">
                <div className="flex justify-between text-xl font-bold">
                  <span>Total</span>
                  <span className="text-green-600">R$ {total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              className="w-full mt-6 bg-gradient-to-r from-green-500 to-blue-500 text-white py-4 rounded-xl font-bold text-lg hover:from-green-600 hover:to-blue-600 transition-all duration-200 flex items-center justify-center space-x-2 shadow-lg"
            >
              <span>Finalizar Compra</span>
              <ArrowRight className="h-5 w-5" />
            </button>

            {/* Benefits */}
            <div className="mt-6 space-y-3">
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Truck className="h-5 w-5 text-green-500" />
                <span>Frete grátis acima de R$ 100</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Shield className="h-5 w-5 text-blue-500" />
                <span>Compra 100% segura</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <CreditCard className="h-5 w-5 text-purple-500" />
                <span>Parcelamento em até 12x</span>
              </div>
            </div>
          </div>

          {/* Continue Shopping */}
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl p-6 border border-yellow-200">
            <h3 className="font-bold text-gray-900 mb-3">Continue Comprando</h3>
            <p className="text-gray-700 text-sm mb-4">
              Descubra mais HQs incríveis em nossa coleção completa!
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-yellow-400 rounded-full"></span>
                <span>Novas aventuras de Tintim</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-orange-400 rounded-full"></span>
                <span>Coleção completa de Asterix</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 bg-red-400 rounded-full"></span>
                <span>Super-heróis clássicos</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Cart
