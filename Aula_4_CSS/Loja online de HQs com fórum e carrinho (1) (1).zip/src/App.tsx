
import React, { useState } from 'react'
import { Toaster } from 'react-hot-toast'
import Header from './components/Header'
import Catalog from './pages/Catalog'
import ComicDetail from './pages/ComicDetail'
import Forum from './pages/Forum'
import Cart from './pages/Cart'
import { CartProvider } from './context/CartContext'

type Page = 'catalog' | 'comic-detail' | 'forum' | 'cart'

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('catalog')
  const [selectedComicId, setSelectedComicId] = useState<string | null>(null)

  const handleComicSelect = (comicId: string) => {
    setSelectedComicId(comicId)
    setCurrentPage('comic-detail')
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'catalog':
        return <Catalog onComicSelect={handleComicSelect} />
      case 'comic-detail':
        return (
          <ComicDetail 
            comicId={selectedComicId} 
            onBack={() => setCurrentPage('catalog')} 
          />
        )
      case 'forum':
        return <Forum />
      case 'cart':
        return <Cart />
      default:
        return <Catalog onComicSelect={handleComicSelect} />
    }
  }

  return (
    <CartProvider>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#1f2937',
              color: '#f9fafb',
              borderRadius: '12px',
              padding: '16px',
              fontSize: '14px'
            },
            success: {
              style: {
                background: '#059669',
              },
            },
            error: {
              style: {
                background: '#dc2626',
              },
            },
          }}
        />
        
        <Header 
          currentPage={currentPage} 
          onPageChange={setCurrentPage} 
        />
        
        <main className="container mx-auto px-4 py-8">
          {renderPage()}
        </main>
        
        <footer className="bg-gray-900 text-white py-12 mt-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4 text-yellow-400">HQ Mania</h3>
                <p className="text-gray-300">
                  A melhor loja de histórias em quadrinhos do Brasil. 
                  Qualidade garantida e entrega rápida.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Categorias</h4>
                <ul className="space-y-2 text-gray-300">
                  <li>Tintim</li>
                  <li>Asterix</li>
                  <li>Super-heróis</li>
                  <li>Lançamentos</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Atendimento</h4>
                <ul className="space-y-2 text-gray-300">
                  <li>FAQ</li>
                  <li>Contato</li>
                  <li>Trocas e Devoluções</li>
                  <li>Frete Grátis</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4">Conecte-se</h4>
                <ul className="space-y-2 text-gray-300">
                  <li>Newsletter</li>
                  <li>Facebook</li>
                  <li>Instagram</li>
                  <li>Twitter</li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2025 HQ Mania. Todos os direitos reservados.</p>
            </div>
          </div>
        </footer>
      </div>
    </CartProvider>
  )
}

export default App
