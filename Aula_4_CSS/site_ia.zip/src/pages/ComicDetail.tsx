
import React, { useState, useEffect } from 'react'
import { ArrowLeft, Star, ShoppingCart, Heart, Share2, Users, Calendar, BookOpen, Award } from 'lucide-react'
import toast from 'react-hot-toast'
import { lumi } from '../lib/lumi'
import { useCart } from '../context/CartContext'

interface Comic {
  _id: string
  title: string
  series: string
  author: string
  price: number
  category: string
  description: string
  imageUrl: string
  rating: number
  totalReviews: number
  salesCount: number
  inStock: boolean
  stockQuantity: number
  publishYear: number
  pages: number
}

interface Review {
  _id: string
  comicId: string
  userName: string
  rating: number
  comment: string
  helpful: number
  verified: boolean
  createdAt: string
}

interface ComicDetailProps {
  comicId: string | null
  onBack: () => void
}

const ComicDetail: React.FC<ComicDetailProps> = ({ comicId, onBack }) => {
  const [comic, setComic] = useState<Comic | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [showAllReviews, setShowAllReviews] = useState(false)
  const { addToCart } = useCart()

  useEffect(() => {
    if (comicId) {
      fetchComicDetails()
      fetchReviews()
    }
  }, [comicId])

  const fetchComicDetails = async () => {
    if (!comicId) return

    try {
      setLoading(true)
      const comicData = await lumi.entities.comics.get(comicId)
      setComic(comicData)
    } catch (error) {
      console.error('Erro ao carregar detalhes da HQ:', error)
      toast.error('Erro ao carregar detalhes da HQ')
    } finally {
      setLoading(false)
    }
  }

  const fetchReviews = async () => {
    try {
      // Simulate fetching reviews - in real app, filter by comicId
      const { list } = await lumi.entities.reviews.list()
      setReviews(list || [])
    } catch (error) {
      console.error('Erro ao carregar reviews:', error)
    }
  }

  const handleAddToCart = () => {
    if (!comic) return

    if (!comic.inStock) {
      toast.error('Este produto está esgotado')
      return
    }

    addToCart({
      id: comic._id,
      title: comic.title,
      price: comic.price,
      imageUrl: comic.imageUrl
    })

    toast.success(`${comic.title} adicionado ao carrinho!`)
  }

  const renderStars = (rating: number, size = 'h-5 w-5') => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`${size} ${
          i < Math.floor(rating)
            ? 'text-yellow-400 fill-current'
            : 'text-gray-300'
        }`}
      />
    ))
  }

  const getSeriesDisplayName = (series: string) => {
    switch (series) {
      case 'tintin': return 'Tintim'
      case 'asterix': return 'Asterix'
      case 'super-heroes': return 'Super-heróis'
      default: return series
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500"></div>
      </div>
    )
  }

  if (!comic) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-600 mb-4">HQ não encontrada</h2>
        <button
          onClick={onBack}
          className="bg-yellow-500 text-white px-6 py-3 rounded-lg hover:bg-yellow-600 transition-colors"
        >
          Voltar ao catálogo
        </button>
      </div>
    )
  }

  const displayedReviews = showAllReviews ? reviews : reviews.slice(0, 3)

  return (
    <div className="space-y-8">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
      >
        <ArrowLeft className="h-5 w-5" />
        <span>Voltar ao catálogo</span>
      </button>

      {/* Main Content */}
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
          {/* Image */}
          <div className="space-y-4">
            <div className="relative">
              <img
                src={comic.imageUrl}
                alt={comic.title}
                className="w-full h-96 lg:h-[500px] object-cover rounded-xl"
              />
              <div className="absolute top-4 left-4">
                <span className="bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  {getSeriesDisplayName(comic.series)}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <button className="flex-1 flex items-center justify-center space-x-2 bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors">
                <Heart className="h-5 w-5" />
                <span>Favoritar</span>
              </button>
              <button className="flex-1 flex items-center justify-center space-x-2 bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors">
                <Share2 className="h-5 w-5" />
                <span>Compartilhar</span>
              </button>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
                {comic.title}
              </h1>
              <p className="text-xl text-gray-600">por {comic.author}</p>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                {renderStars(comic.rating)}
              </div>
              <span className="text-lg font-semibold">{comic.rating.toFixed(1)}</span>
              <span className="text-gray-600">({comic.totalReviews} avaliações)</span>
            </div>

            {/* Price */}
            <div className="flex items-center space-x-4">
              <span className="text-4xl font-bold text-green-600">
                R$ {comic.price.toFixed(2)}
              </span>
              <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                Frete grátis
              </span>
            </div>

            {/* Stock Status */}
            <div className="flex items-center space-x-2">
              {comic.inStock ? (
                <>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-green-600 font-medium">
                    Em estoque ({comic.stockQuantity} unidades)
                  </span>
                </>
              ) : (
                <>
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-red-600 font-medium">Esgotado</span>
                </>
              )}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 py-4 border-t border-gray-200">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="h-5 w-5 text-blue-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900">{comic.salesCount}</div>
                <div className="text-sm text-gray-600">Vendidos</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Calendar className="h-5 w-5 text-purple-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900">{comic.publishYear}</div>
                <div className="text-sm text-gray-600">Ano</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <BookOpen className="h-5 w-5 text-orange-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900">{comic.pages}</div>
                <div className="text-sm text-gray-600">Páginas</div>
              </div>
            </div>

            {/* Add to Cart */}
            <button
              onClick={handleAddToCart}
              disabled={!comic.inStock}
              className={`w-full flex items-center justify-center space-x-3 py-4 rounded-xl font-bold text-lg transition-all duration-200 ${
                comic.inStock
                  ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white hover:from-yellow-500 hover:to-orange-600 shadow-lg hover:shadow-xl'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <ShoppingCart className="h-6 w-6" />
              <span>{comic.inStock ? 'Adicionar ao Carrinho' : 'Produto Esgotado'}</span>
            </button>

            {/* Description */}
            <div className="pt-6 border-t border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-3">Descrição</h3>
              <p className="text-gray-700 leading-relaxed">{comic.description}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Award className="h-6 w-6 text-yellow-500" />
          <h2 className="text-2xl font-bold text-gray-900">Avaliações dos Clientes</h2>
        </div>

        {reviews.length > 0 ? (
          <div className="space-y-6">
            {displayedReviews.map((review) => (
              <div key={review._id} className="border-b border-gray-200 pb-6 last:border-b-0">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-semibold text-gray-900">{review.userName}</span>
                      {review.verified && (
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Compra verificada
                        </span>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1">
                        {renderStars(review.rating, 'h-4 w-4')}
                      </div>
                      <span className="text-sm text-gray-600">
                        {formatDate(review.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
                
                <p className="text-gray-700 mb-3">{review.comment}</p>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <button className="hover:text-gray-900 transition-colors">
                    👍 Útil ({review.helpful})
                  </button>
                  <button className="hover:text-gray-900 transition-colors">
                    Responder
                  </button>
                </div>
              </div>
            ))}

            {reviews.length > 3 && (
              <div className="text-center">
                <button
                  onClick={() => setShowAllReviews(!showAllReviews)}
                  className="bg-gray-100 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  {showAllReviews ? 'Ver menos avaliações' : `Ver todas as ${reviews.length} avaliações`}
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-4">
              <Star className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              Ainda não há avaliações
            </h3>
            <p className="text-gray-500">
              Seja o primeiro a avaliar este produto!
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

export default ComicDetail
