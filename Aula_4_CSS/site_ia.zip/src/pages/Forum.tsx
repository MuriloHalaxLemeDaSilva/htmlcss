
import React, { useState, useEffect } from 'react'
import { MessageSquare, ThumbsUp, Eye, Pin, Plus, Search, Filter, Clock, TrendingUp } from 'lucide-react'
import { lumi } from '../lib/lumi'

interface ForumPost {
  _id: string
  title: string
  content: string
  author: string
  category: string
  likes: number
  replies: number
  views: number
  pinned: boolean
  createdAt: string
  lastActivity: string
}

const Forum: React.FC = () => {
  const [posts, setPosts] = useState<ForumPost[]>([])
  const [filteredPosts, setFilteredPosts] = useState<ForumPost[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [sortBy, setSortBy] = useState('activity')
  const [showNewPostForm, setShowNewPostForm] = useState(false)

  useEffect(() => {
    fetchPosts()
  }, [])

  useEffect(() => {
    filterAndSortPosts()
  }, [posts, selectedCategory, searchTerm, sortBy])

  const fetchPosts = async () => {
    try {
      setLoading(true)
      const { list } = await lumi.entities.forum_posts.list()
      setPosts(list || [])
    } catch (error) {
      console.error('Erro ao carregar posts do fórum:', error)
    } finally {
      setLoading(false)
    }
  }

  const filterAndSortPosts = () => {
    let filtered = [...posts]

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(post => post.category === selectedCategory)
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(post =>
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.author.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Sort posts
    switch (sortBy) {
      case 'activity':
        filtered.sort((a, b) => new Date(b.lastActivity).getTime() - new Date(a.lastActivity).getTime())
        break
      case 'likes':
        filtered.sort((a, b) => b.likes - a.likes)
        break
      case 'replies':
        filtered.sort((a, b) => b.replies - a.replies)
        break
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        break
      default:
        break
    }

    // Pinned posts first
    const pinnedPosts = filtered.filter(post => post.pinned)
    const regularPosts = filtered.filter(post => !post.pinned)
    
    setFilteredPosts([...pinnedPosts, ...regularPosts])
  }

  const getCategoryDisplayName = (category: string) => {
    switch (category) {
      case 'tintin': return 'Tintim'
      case 'asterix': return 'Asterix'
      case 'super-heroes': return 'Super-heróis'
      case 'geral': return 'Geral'
      case 'novidades': return 'Novidades'
      default: return category
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'tintin': return 'bg-blue-100 text-blue-800'
      case 'asterix': return 'bg-yellow-100 text-yellow-800'
      case 'super-heroes': return 'bg-red-100 text-red-800'
      case 'geral': return 'bg-gray-100 text-gray-800'
      case 'novidades': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return 'Há alguns minutos'
    if (diffInHours < 24) return `Há ${diffInHours}h`
    if (diffInHours < 48) return 'Ontem'
    return date.toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })
  }

  const getStats = () => {
    const totalPosts = posts.length
    const totalReplies = posts.reduce((sum, post) => sum + post.replies, 0)
    const totalViews = posts.reduce((sum, post) => sum + post.views, 0)
    const activeUsers = new Set(posts.map(post => post.author)).size

    return { totalPosts, totalReplies, totalViews, activeUsers }
  }

  const stats = getStats()

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-4">Fórum da Comunidade</h1>
            <p className="text-xl opacity-90 mb-6 lg:mb-0">
              Discuta suas HQs favoritas com outros fãs apaixonados
            </p>
          </div>
          <button
            onClick={() => setShowNewPostForm(true)}
            className="flex items-center space-x-2 bg-white text-blue-600 px-6 py-3 rounded-lg font-bold hover:bg-gray-100 transition-colors"
          >
            <Plus className="h-5 w-5" />
            <span>Novo Post</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-3 rounded-lg">
              <MessageSquare className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.totalPosts}</div>
              <div className="text-sm text-gray-600">Posts</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3">
            <div className="bg-green-100 p-3 rounded-lg">
              <ThumbsUp className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.totalReplies}</div>
              <div className="text-sm text-gray-600">Respostas</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Eye className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.totalViews}</div>
              <div className="text-sm text-gray-600">Visualizações</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center space-x-3">
            <div className="bg-orange-100 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.activeUsers}</div>
              <div className="text-sm text-gray-600">Usuários Ativos</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Buscar discussões..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Category Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="pl-10 pr-8 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white min-w-48"
            >
              <option value="all">Todas as Categorias</option>
              <option value="tintin">Tintim</option>
              <option value="asterix">Asterix</option>
              <option value="super-heroes">Super-heróis</option>
              <option value="geral">Geral</option>
              <option value="novidades">Novidades</option>
            </select>
          </div>

          {/* Sort */}
          <div className="relative">
            <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="pl-10 pr-8 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white min-w-48"
            >
              <option value="activity">Última Atividade</option>
              <option value="likes">Mais Curtidos</option>
              <option value="replies">Mais Respostas</option>
              <option value="newest">Mais Recentes</option>
            </select>
          </div>
        </div>
      </div>

      {/* Posts List */}
      <div className="space-y-4">
        {filteredPosts.map((post) => (
          <div
            key={post._id}
            className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-200 cursor-pointer"
          >
            <div className="flex items-start space-x-4">
              {/* Post Content */}
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-3">
                  {post.pinned && (
                    <Pin className="h-5 w-5 text-yellow-500" />
                  )}
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(post.category)}`}>
                    {getCategoryDisplayName(post.category)}
                  </span>
                  <span className="text-sm text-gray-500">
                    por {post.author}
                  </span>
                  <span className="text-sm text-gray-400">
                    {formatDate(post.createdAt)}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-3 hover:text-blue-600 transition-colors">
                  {post.title}
                </h3>

                <p className="text-gray-700 mb-4 line-clamp-2">
                  {post.content}
                </p>

                <div className="flex items-center space-x-6 text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{post.likes}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MessageSquare className="h-4 w-4" />
                    <span>{post.replies} respostas</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{post.views} visualizações</span>
                  </div>
                  <div className="text-xs text-gray-400">
                    Última atividade: {formatDate(post.lastActivity)}
                  </div>
                </div>
              </div>

              {/* Stats Column */}
              <div className="text-center space-y-2 min-w-20">
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-lg font-bold text-gray-900">{post.replies}</div>
                  <div className="text-xs text-gray-600">Respostas</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-lg font-bold text-gray-900">{post.views}</div>
                  <div className="text-xs text-gray-600">Views</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredPosts.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <MessageSquare className="h-16 w-16 mx-auto" />
          </div>
          <h3 className="text-xl font-semibold text-gray-600 mb-2">
            Nenhuma discussão encontrada
          </h3>
          <p className="text-gray-500 mb-6">
            Seja o primeiro a iniciar uma discussão sobre este tópico!
          </p>
          <button
            onClick={() => setShowNewPostForm(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Criar Novo Post
          </button>
        </div>
      )}

      {/* New Post Modal Placeholder */}
      {showNewPostForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Criar Nova Discussão</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Categoria
                </label>
                <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="geral">Geral</option>
                  <option value="tintin">Tintim</option>
                  <option value="asterix">Asterix</option>
                  <option value="super-heroes">Super-heróis</option>
                  <option value="novidades">Novidades</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Título
                </label>
                <input
                  type="text"
                  placeholder="Digite o título da discussão..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Conteúdo
                </label>
                <textarea
                  rows={6}
                  placeholder="Compartilhe seus pensamentos..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="flex space-x-4 mt-8">
              <button className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                Publicar Discussão
              </button>
              <button
                onClick={() => setShowNewPostForm(false)}
                className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg hover:bg-gray-300 transition-colors font-medium"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Forum
