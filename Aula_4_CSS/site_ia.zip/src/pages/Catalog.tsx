
import React, { useState, useEffect } from 'react'
import { Search, Filter, Star, TrendingUp, Eye } from 'lucide-react'
import { lumi } from '../lib/lumi'

interface Comic {
  _id: string
  title: string
  series: string
  author: string
  price: number
  category: string
  description: string
  imageUrl: string
  rating: number
  totalReviews: number
  salesCount: number
  inStock: boolean
  stockQuantity: number
  publishYear: number
  pages: number
}

interface CatalogProps {
  onComicSelect: (comicId: string) => void
}

const Catalog: React.FC<CatalogProps> = ({ onComicSelect }) => {
  const [comics, setComics] = useState<Comic[]>([])
  const [filteredComics, setFilteredComics] = useState<Comic[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSeries, setSelectedSeries] = useState('all')
  const [sortBy, setSortBy] = useState('popularity')

  useEffect(() => {
    fetchComics()
  }, [])

  useEffect(() => {
    filterAndSortComics()
  }, [comics, searchTerm, selectedSeries, sortBy])

  const fetchComics = async () => {
    try {
      setLoading(true)
      const { list } = await lumi.entities.comics.list()
      setComics(list || [])
    } catch (error) {
      console.error('Erro ao carregar HQs:', error)
    } finally {
      setLoading(false)
    }
  }

  const filterAndSortComics = () => {
    let filtered = [...comics]

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(comic =>
        comic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comic.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        comic.category.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filter by series
    if (selectedSeries !== 'all') {
      filtered = filtered.filter(comic => comic.series === selectedSeries)
    }

    // Sort comics
    switch (sortBy) {
      case 'popularity':
        filtered.sort((a, b) => b.salesCount - a.salesCount)
        break
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price)
        break
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price)
        break
      case 'newest':
        filtered.sort((a, b) => b.publishYear - a.publishYear)
        break
      default:
        break
    }

    setFilteredComics(filtered)
  }

  const getSeriesDisplayName = (series: string) => {
    switch (series) {
      case 'tintin': return 'Tintim'
      case 'asterix': return 'Asterix'
      case 'super-heroes': return 'Super-heróis'
      default: return series
    }
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating)
            ? 'text-yellow-400 fill-current'
            : 'text-gray-300'
        }`}
      />
    ))
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500"></div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-2xl p-8 text-white">
        <div className="max-w-4xl">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Explore o Universo dos Quadrinhos
          </h1>
          <p className="text-xl md:text-2xl mb-6 opacity-90">
            Descubra as melhores aventuras de Tintim, Asterix e seus super-heróis favoritos
          </p>
          <div className="flex flex-wrap gap-4 text-sm md:text-base">
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2">
              <TrendingUp className="h-5 w-5" />
              <span>Mais Vendidos</span>
            </div>
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2">
              <Star className="h-5 w-5" />
              <span>Melhor Avaliados</span>
            </div>
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2">
              <Eye className="h-5 w-5" />
              <span>Frete Grátis</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Buscar por título, autor ou categoria..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
          </div>

          {/* Series Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <select
              value={selectedSeries}
              onChange={(e) => setSelectedSeries(e.target.value)}
              className="pl-10 pr-8 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent appearance-none bg-white min-w-48"
            >
              <option value="all">Todas as Séries</option>
              <option value="tintin">Tintim</option>
              <option value="asterix">Asterix</option>
              <option value="super-heroes">Super-heróis</option>
            </select>
          </div>

          {/* Sort */}
          <div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent appearance-none bg-white min-w-48"
            >
              <option value="popularity">Mais Populares</option>
              <option value="rating">Melhor Avaliados</option>
              <option value="price-low">Menor Preço</option>
              <option value="price-high">Maior Preço</option>
              <option value="newest">Mais Recentes</option>
            </select>
          </div>
        </div>
      </div>

      {/* Results Summary */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">
          {filteredComics.length} HQs encontradas
        </h2>
        {selectedSeries !== 'all' && (
          <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
            Série: {getSeriesDisplayName(selectedSeries)}
          </span>
        )}
      </div>

      {/* Comics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredComics.map((comic) => (
          <div
            key={comic._id}
            className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
            onClick={() => onComicSelect(comic._id)}
          >
            <div className="relative">
              <img
                src={comic.imageUrl}
                alt={comic.title}
                className="w-full h-64 object-cover"
              />
              <div className="absolute top-3 left-3">
                <span className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                  {getSeriesDisplayName(comic.series)}
                </span>
              </div>
              {!comic.inStock && (
                <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                  <span className="bg-red-500 text-white px-4 py-2 rounded-lg font-bold">
                    Esgotado
                  </span>
                </div>
              )}
            </div>

            <div className="p-4">
              <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2">
                {comic.title}
              </h3>
              
              <p className="text-gray-600 text-sm mb-2">por {comic.author}</p>
              
              <div className="flex items-center space-x-1 mb-3">
                {renderStars(comic.rating)}
                <span className="text-sm text-gray-600 ml-2">
                  ({comic.totalReviews})
                </span>
              </div>

              <div className="flex items-center justify-between mb-3">
                <span className="text-2xl font-bold text-green-600">
                  R$ {comic.price.toFixed(2)}
                </span>
                <span className="text-sm text-gray-500">
                  {comic.salesCount} vendidos
                </span>
              </div>

              <div className="text-xs text-gray-500 space-y-1">
                <div>Ano: {comic.publishYear}</div>
                <div>{comic.pages} páginas</div>
                {comic.inStock && (
                  <div className="text-green-600 font-medium">
                    {comic.stockQuantity} em estoque
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredComics.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <Search className="h-16 w-16 mx-auto" />
          </div>
          <h3 className="text-xl font-semibold text-gray-600 mb-2">
            Nenhuma HQ encontrada
          </h3>
          <p className="text-gray-500">
            Tente ajustar os filtros ou termos de busca
          </p>
        </div>
      )}
    </div>
  )
}

export default Catalog
