
import React from 'react'
import { ShoppingCart, MessageSquare, BookOpen, Star } from 'lucide-react'
import { useCart } from '../context/CartContext'

interface HeaderProps {
  currentPage: string
  onPageChange: (page: 'catalog' | 'forum' | 'cart') => void
}

const Header: React.FC<HeaderProps> = ({ currentPage, onPageChange }) => {
  const { getTotalItems } = useCart()
  const totalItems = getTotalItems()

  return (
    <header className="bg-white shadow-lg border-b-4 border-yellow-400">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div 
            className="flex items-center space-x-3 cursor-pointer"
            onClick={() => onPageChange('catalog')}
          >
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-xl">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">HQ Mania</h1>
              <p className="text-sm text-gray-600">Editora de Quadrinhos</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => onPageChange('catalog')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                currentPage === 'catalog' || currentPage === 'comic-detail'
                  ? 'bg-yellow-100 text-yellow-800 shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <BookOpen className="h-5 w-5" />
              <span className="font-medium">Catálogo</span>
            </button>

            <button
              onClick={() => onPageChange('forum')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                currentPage === 'forum'
                  ? 'bg-blue-100 text-blue-800 shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <MessageSquare className="h-5 w-5" />
              <span className="font-medium">Fórum</span>
            </button>

            <button
              onClick={() => onPageChange('cart')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 relative ${
                currentPage === 'cart'
                  ? 'bg-green-100 text-green-800 shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <ShoppingCart className="h-5 w-5" />
              <span className="font-medium">Carrinho</span>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
                  {totalItems}
                </span>
              )}
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => onPageChange('cart')}
              className="relative p-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              <ShoppingCart className="h-6 w-6" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                  {totalItems}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden pb-4">
          <div className="flex space-x-4">
            <button
              onClick={() => onPageChange('catalog')}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-lg transition-all duration-200 ${
                currentPage === 'catalog' || currentPage === 'comic-detail'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <BookOpen className="h-5 w-5" />
              <span className="font-medium">Catálogo</span>
            </button>

            <button
              onClick={() => onPageChange('forum')}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-lg transition-all duration-200 ${
                currentPage === 'forum'
                  ? 'bg-blue-100 text-blue-800'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <MessageSquare className="h-5 w-5" />
              <span className="font-medium">Fórum</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
